﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Orologio
{
    internal class COrario
    {
        private int _ore;
        private int _minuti;
        private int _secondi;


        //costruttore di default 
        public COrario()
        {
            _ore = 00;
            _minuti = 00;
            _secondi = 00;
        }

        public COrario(int ore, int minuti, int secondi)
        {
            ore = _ore;
            minuti = _minuti;
            secondi = _secondi;
        }
        public COrario(int secondiTotali)
        {
            secondiTotali += _secondi;
        }
        public int ore
        {
            get { return _ore; }
            set
            {


                Normalizza();


            }
        }

        public int minuti
        {
            get { return _minuti; }
            set
            {


                Normalizza();
                _minuti = value;
            }



        }
        public int secondi
        {
            get { return _secondi; }
            set
            {

                Normalizza();
                _secondi = value;

            }
        }
        public void Normalizza()
        {
            if (_secondi >= 60)
            {
                _minuti += _secondi / 60;
                _secondi %= 60;
            }
            if (_minuti >= 60)
            {
                _ore += _minuti / 60;
                _minuti %= 60;
            }
            if (_ore >= 24)
            {
                _ore -= 24;
            }
        }

        public override string ToString()
        {
            return _ore.ToString() + ":" + _minuti.ToString() + ":" + _secondi.ToString();

        }

        public int ToSecondi()
        {
            return (_ore * 3600) + (_minuti * 60) + _secondi;
        }
        public void Aggiungi(int secondi)
        {
            _secondi += secondi;
            Normalizza();
        }
        public void Aggiungi(int ore, int minuti, int secondi)
        {
            _ore += ore;
            _minuti += minuti;
            _secondi += secondi;

        }
        public static COrario Confronta(COrario a, COrario b)
        {
            if (a.ore > b.ore)
            {
                return a;
            }
            if (b.ore > a.ore)
            {
                return b;
            }
            if (a.minuti > b.minuti)
            {
                return a;
            }
            if (b.minuti > a.minuti)
            {
                return b;
            }
            if (a.secondi > b.secondi)
            {
                return a;
            }

            return b;

        }


    }
}


/
