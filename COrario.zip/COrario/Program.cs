﻿using System;

namespace Orologio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            COrario orologio1 = new COrario();
            COrario orologio2 = new COrario();

            orologio1.ore = 10;
            orologio1.minuti = 45;
            orologio1.secondi = 30;

            orologio2.ore = 12;
            orologio2.minuti = 15;
            orologio2.secondi = 50;

            Console.WriteLine("Orologio 1: " + orologio1);
            Console.WriteLine("Orologio 2: " + orologio2);

            Console.WriteLine("Secondi totali Orologio 1: " + orologio1.ToSecondi());

            orologio1.Aggiungi(90);

            Console.WriteLine("Orologio 1 dopo aggiunta di 90 secondi:");
            Console.WriteLine(orologio1);

            orologio2.Aggiungi(1, 50, 30);
            orologio2.Normalizza();

            Console.WriteLine("\nOrologio 2 dopo aggiunta:");
            Console.WriteLine(orologio2);

            COrario maggiore = COrario.Confronta(orologio1, orologio2);

            Console.WriteLine("Orario maggiore:");
            Console.WriteLine(maggiore);

            
        }
    }
}